const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const IncidenciaSchema = new Schema ({
    tipoIncidencia: String,
    prioridad: String,
    grupo: String,
    asunto: String,
    descripcion: String,
    fechaPropuesta: String,
    estado: {
        type: Boolean,
        default: false
    }
});

module.exports = mongoose.model('incidencias', IncidenciaSchema);