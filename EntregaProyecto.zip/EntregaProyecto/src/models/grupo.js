const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const GrupoSchema = new Schema ({
    nombre: String
});

module.exports = mongoose.model('grupos', GrupoSchema);