const router = require('express').Router();
const passport = require('passport');

const express = require('express');
//const router2 = express.Router();
const Incidencia = require('../models/incidencia');
const Tipoincidencia = require('../models/tipoincidencia');
const Prioridad = require('../models/prioridad');
const Grupo = require('../models/grupo');


// R1
router.get('/', async (req, res) => {
  const incidencias = await Incidencia.find();
  const tipoincidencias = await Tipoincidencia.find();
  const prioridades = await Prioridad.find();
  const grupos = await Grupo.find();
  res.render('index', {
      incidencias,
      tipoincidencias,
      prioridades,
      grupos
  });
});

router.get('/signup', (req, res, next) => {
  res.render('signup');
});

router.post('/signup', passport.authenticate('local-signup', {
  successRedirect: '/profile',
  failureRedirect: '/signup',
  failureFlash: true
})); 

router.get('/signin', (req, res, next) => {
  res.render('signin');
});


router.post('/signin', passport.authenticate('local-signin', {
  successRedirect: '/profile',
  failureRedirect: '/signin',
  failureFlash: true
}));

router.get('/profile',isAuthenticated, async(req, res, next) => {
  const incidencias = await Incidencia.find();
  const tipoincidencias = await Tipoincidencia.find();
  const prioridades = await Prioridad.find();
  const grupos = await Grupo.find();
  res.render('profile', {
    incidencias,
    tipoincidencias,
    prioridades,
    grupos
  });
});

router.get('/logout', (req, res, next) => {
  req.logout();
  res.redirect('/');
});


function isAuthenticated(req, res, next) {
  if(req.isAuthenticated()) {
    return next();
  }

  res.redirect('/')
}


// Inserción.
router.post('/add', async (req, res) => {
  const incidencia = new Incidencia(req.body);
  await incidencia.save();
  res.redirect('/profile');
});

router.get('/turn/:id', async (req, res) => {
  const { id } = req.params;
  const incidencia = await Incidencia.findById(id);
  incidencia.estado = !incidencia.estado;
  await incidencia.save();
  res.redirect('/profile');
});

router.get('/delete/:id', async (req, res) => {
  const { id } = req.params;
  await Incidencia.remove({_id: id});
  res.redirect('/profile');
});

// Actualización 1
router.get('/edit/:id', async (req, res) => {
  const { id } = req.params;
  const incidencia = await Incidencia.findById(id);
  const incidencias = await Incidencia.find();
  const tipoincidencias = await Tipoincidencia.find();
  const prioridades = await Prioridad.find();
  const grupos = await Grupo.find();
  res.render('edit', {
      incidencia,
      incidencias,
      tipoincidencias,
      prioridades,
      grupos
  });
});

// Actualización 2
router.post('/edit/:id', async (req, res) => {
  const { id } = req.params;
  await Incidencia.update({_id: id}, req.body);
  res.redirect('/profile');
});

// Eliminación 1 
router.get('/conf/:id', async (req, res) => {
  const { id } = req.params;
  const incidencia = await Incidencia.findById(id);
  res.render('modal', {
      incidencia
  });
});

// Eliminación 2
router.post('/conf/:id', async (req, res) => {
  const { id } = req.params;
  res.redirect('/profile');
});


module.exports = router;
